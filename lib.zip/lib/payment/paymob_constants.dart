class PaymobConstants {
  static const String apiKey =
      'ZXlKaGJHY2lPaUpJVXpVeE1pSXNJblI1Y0NJNklrcFhWQ0o5LmV5SmpiR0Z6Y3lJNklrMWxjbU5vWVc1MElpd2ljSEp2Wm1sc1pWOXdheUk2TVRBME9EYzNNU3dpYm1GdFpTSTZJbWx1YVhScFlXd2lmUS4taWtielpIbFdqVWo3eGhnczIwVHNxZE5XcURfOW5Ba0Npby1aalNzSFBxM1gyaTZLRkc2THE3TG5TTk1EX0lva2kzMmgzVTgxc0xraGtxaE5RZmtpZw=='; // كمل المفتاح هنا
  static const int integrationCardId = 5108855;
  static const int integrationWalletId = 5108897;
  static const String iFrameId = '926704';
  static const String currency = 'EGP';
  static const String paymobBaseUrl = 'https://accept.paymob.com/api';
}
